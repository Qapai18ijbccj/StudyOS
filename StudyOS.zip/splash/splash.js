document.addEventListener("DOMContentLoaded", () => {

    const percentage = document.getElementById("percentage");
    const progressFill = document.getElementById("progressFill");

    let progress = 0;

    const duration = 2500;
    const intervalTime = 25;

    const increment = 100 / (duration / intervalTime);

    const loading = setInterval(() => {

        progress += increment;

        if (progress >= 100) {

            progress = 100;

            clearInterval(loading);

        }

        const value = Math.floor(progress);

        percentage.textContent = value + "%";

        progressFill.style.width = value + "%";

    }, intervalTime);


    setTimeout(() => {

        window.location.href = "../home/home.html";

    }, duration + 100);

});