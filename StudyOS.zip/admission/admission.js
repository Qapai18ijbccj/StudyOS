/* =====================================================
   StudyOS - Admission / معدل القبول
   مصدر البيانات:
   ../data/colleges_data_with_province.json
===================================================== */

let collegesData = [];

let currentAverage = 50;
let selectedBranch = "";
let selectedGovernorate = "";


/* =====================================================
   ELEMENTS
===================================================== */

const averageSlider = document.getElementById("averageSlider");
const averageValue = document.getElementById("averageValue");
const sliderProgress = document.getElementById("sliderProgress");
const sliderThumb = document.getElementById("sliderThumb");

const collegeList = document.getElementById("collegeList");
const emptyState = document.getElementById("emptyState");
const resultsCount = document.getElementById("resultsCount");


/* =====================================================
   LOAD JSON
===================================================== */

async function loadCollegesData() {

    try {

        /*
          admission.html موجود داخل مجلد admission
          لذلك نرجع خطوة للخلف ثم ندخل data
        */

        const response = await fetch(
            "../data/colleges_data_with_province.json"
        );

        if (!response.ok) {
            throw new Error(
                "تعذر تحميل ملف الكليات"
            );
        }

        collegesData = await response.json();

        console.log(
            "StudyOS: تم تحميل البيانات",
            collegesData.length
        );

        /*
          إذا كانت الاختيارات محفوظة سابقاً
          نعيد عرض النتائج
        */

        updateResults();

    } catch (error) {

        console.error(
            "StudyOS JSON Error:",
            error
        );

        showDataError();
    }
}


/* =====================================================
   SLIDER
===================================================== */

function updateSlider() {

    if (!averageSlider) return;

    currentAverage = parseFloat(
        averageSlider.value
    );

    if (averageValue) {

        averageValue.textContent =
            currentAverage.toFixed(2);

    }

    const min =
        parseFloat(averageSlider.min);

    const max =
        parseFloat(averageSlider.max);

    const percentage =
        ((currentAverage - min) /
        (max - min)) * 100;


    /*
      شريط التقدم
    */

    if (sliderProgress) {

        sliderProgress.style.width =
            percentage + "%";

    }


    /*
      مكان الدائرة
    */

    if (sliderThumb) {

        sliderThumb.style.right =
            `calc(${percentage}% - 10px)`;

    }


    updateResults();
}


/* =====================================================
   SLIDER EVENTS
===================================================== */

if (averageSlider) {

    averageSlider.addEventListener(
        "input",
        updateSlider
    );

    averageSlider.addEventListener(
        "change",
        updateSlider
    );
}


/* =====================================================
   BRANCH DROPDOWN
===================================================== */

function toggleDropdown(id) {

    const dropdown =
        document.getElementById(id);

    if (!dropdown) return;


    /*
      نغلق باقي القوائم
    */

    document
        .querySelectorAll(".dropdown-card")
        .forEach(card => {

            if (card.id !== id) {

                card.classList.remove(
                    "open"
                );

            }

        });


    dropdown.classList.toggle(
        "open"
    );
}


/* =====================================================
   SELECT BRANCH
===================================================== */

function selectBranch(
    value,
    text
) {

    selectedBranch = value;


    const branchText =
        document.getElementById(
            "branchText"
        );

    if (branchText) {

        branchText.textContent =
            text;

    }


    const dropdown =
        document.getElementById(
            "branchDropdown"
        );

    if (dropdown) {

        dropdown.classList.remove(
            "open"
        );

    }


    updateResults();
}


/* =====================================================
   SELECT GOVERNORATE
===================================================== */

function selectGovernorate(
    value,
    text
) {

    selectedGovernorate = value;


    const governorateText =
        document.getElementById(
            "governorateText"
        );

    if (governorateText) {

        governorateText.textContent =
            text;

    }


    const dropdown =
        document.getElementById(
            "governorateDropdown"
        );

    if (dropdown) {

        dropdown.classList.remove(
            "open"
        );

    }


    updateResults();
}


/* =====================================================
   GOVERNORATE MAPPING
===================================================== */

const governorateMap = {

    baghdad:
        "بغداد",

    nineveh:
        "نينوى",

    basra:
        "البصرة",

    erbil:
        "أربيل",

    sulaymaniyah:
        "السليمانية",

    dohuk:
        "دهوك",

    kirkuk:
        "كركوك",

    anbar:
        "الأنبار",

    najaf:
        "النجف",

    karbala:
        "كربلاء",

    babylon:
        "بابل",

    wasit:
        "واسط",

    diyala:
        "ديالى",

    salahuddin:
        "صلاح الدين",

    dhiqar:
        "ذي قار",

    maysan:
        "ميسان",

    muthanna:
        "المثنى",

    qadisiyah:
        "القادسية"

};


/* =====================================================
   UPDATE RESULTS
===================================================== */

function updateResults() {

    if (!collegeList) return;


    /*
      إذا البيانات لم تصل بعد
    */

    if (!collegesData.length) {

        return;

    }


    /*
      إذا المستخدم لم يختار الفرع والمحافظة
    */

    if (
        !selectedBranch ||
        !selectedGovernorate
    ) {

        showEmptyState();

        return;

    }


    const province =
        governorateMap[
            selectedGovernorate
        ];


    /*
      تحويل الفرع إلى القيمة الموجودة
      داخل JSON
    */

    const branch =
        selectedBranch === "scientific"
            ? "elmi"
            : "adabi";


    /*
      فلترة الكليات
    */

    let results =
        collegesData.filter(
            college => {

                const correctBranch =
                    college.branch === branch;

                const correctProvince =
                    college.province === province;

                const suitableAverage =
                    Number(
                        college.minGrade
                    ) <= currentAverage;


                return (
                    correctBranch &&
                    correctProvince &&
                    suitableAverage
                );

            }
        );


    /*
      ترتيب النتائج:
      الأعلى حداً أدنى أولاً
    */

    results.sort(
        (a, b) =>
            Number(b.minGrade) -
            Number(a.minGrade)
    );


    renderResults(results);
}


/* =====================================================
   SHOW EMPTY STATE
===================================================== */

function showEmptyState() {

    if (emptyState) {

        emptyState.style.display =
            "block";

    }

    if (collegeList) {

        collegeList.innerHTML =
            "";

    }

    if (resultsCount) {

        resultsCount.textContent =
            "0";

    }
}


/* =====================================================
   RENDER RESULTS
===================================================== */

function renderResults(
    results
) {

    if (!collegeList) return;


    collegeList.innerHTML =
        "";


    if (resultsCount) {

        resultsCount.textContent =
            results.length;

    }


    /*
      لا توجد كليات مناسبة
    */

    if (!results.length) {

        if (emptyState) {

            emptyState.style.display =
                "block";

            emptyState.innerHTML = `

                <div class="empty-icon">
                    🎓
                </div>

                <h3>
                    لا توجد كليات مطابقة
                </h3>

                <p>
                    لا توجد كلية ضمن
                    محافظتك وفرعك تستطيع
                    قبول معدلك الحالي.
                </p>

            `;

        }

        return;
    }


    /*
      إخفاء الحالة الفارغة
    */

    if (emptyState) {

        emptyState.style.display =
            "none";

    }


    /*
      إنشاء بطاقات الكليات
    */

    results.forEach(
        college => {

            const minGrade =
                Number(
                    college.minGrade
                );

            const difference =
                currentAverage -
                minGrade;


            const card =
                document.createElement(
                    "div"
                );

            card.className =
                "college-card";


            card.innerHTML = `

                <div class="college-card-top">

                    <div class="college-icon">
                        🎓
                    </div>

                    <div class="college-info">

                        <h3>
                            ${escapeHTML(
                                college.college
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                college.university
                            )}
                        </p>

                    </div>

                </div>


                <div class="college-details">

                    <div class="grade-box">

                        <span>
                            الحد الأدنى
                        </span>

                        <strong>
                            ${minGrade.toFixed(2)}
                        </strong>

                    </div>


                    <div class="grade-box">

                        <span>
                            معدلك
                        </span>

                        <strong>
                            ${currentAverage.toFixed(2)}
                        </strong>

                    </div>


                    <div class="grade-box success">

                        <span>
                            الفرق
                        </span>

                        <strong>
                            +${difference.toFixed(2)}
                        </strong>

                    </div>

                </div>

            `;


            collegeList.appendChild(
                card
            );

        }
    );
}


/* =====================================================
   DATA ERROR
===================================================== */

function showDataError() {

    if (!emptyState) return;


    emptyState.style.display =
        "block";


    emptyState.innerHTML = `

        <div class="empty-icon">
            ⚠️
        </div>

        <h3>
            تعذر تحميل البيانات
        </h3>

        <p>
            تأكد أن ملف
            colleges_data_with_province.json
            موجود داخل مجلد data.
        </p>

    `;


    if (resultsCount) {

        resultsCount.textContent =
            "0";

    }
}


/* =====================================================
   ESCAPE HTML
===================================================== */

function escapeHTML(
    value
) {

    if (value === undefined ||
        value === null) {

        return "";

    }


    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


/* =====================================================
   CLOSE DROPDOWNS WHEN CLICKING OUTSIDE
===================================================== */

document.addEventListener(
    "click",
    function(event) {

        if (
            !event.target.closest(
                ".dropdown-card"
            )
        ) {

            document
                .querySelectorAll(
                    ".dropdown-card"
                )
                .forEach(
                    dropdown => {

                        dropdown.classList.remove(
                            "open"
                        );

                    }
                );

        }

    }
);


/* =====================================================
   NAVIGATION
===================================================== */

function navigate(page) {

    const routes = {

        home:
            "../home/home.html",

        questions:
            "../questions/questions.html",

        admission:
            "admission.html",

        news:
            "../news/news.html",

        settings:
            "../settings/settings.html"

    };


    if (routes[page]) {

        window.location.href =
            routes[page];

    }

}


/* =====================================================
   INITIALIZE
===================================================== */

updateSlider();

loadCollegesData();