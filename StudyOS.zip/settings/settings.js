/* =====================================================
   StudyOS
   SETTINGS.JS
   Dark Mode + Language + Navigation
===================================================== */


/* =====================================================
   DARK MODE - APPLY BEFORE PAGE LOAD
===================================================== */

(function () {

    const savedTheme =
        localStorage.getItem("studyos_theme");

    if (savedTheme === "dark") {

        document.documentElement.setAttribute(
            "data-theme",
            "dark"
        );

    } else {

        document.documentElement.setAttribute(
            "data-theme",
            "light"
        );

    }

})();


/* =====================================================
   PAGE READY
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    setupDarkMode();

    setupLanguage();

});


/* =====================================================
   DARK MODE
===================================================== */

function setupDarkMode() {

    const darkMode =
        document.getElementById("darkMode");

    if (!darkMode) {

        console.error(
            "StudyOS: darkMode غير موجود"
        );

        return;
    }


    const savedTheme =
        localStorage.getItem(
            "studyos_theme"
        ) || "light";


    if (savedTheme === "dark") {

        darkMode.checked = true;

        document.documentElement.setAttribute(
            "data-theme",
            "dark"
        );

    } else {

        darkMode.checked = false;

        document.documentElement.setAttribute(
            "data-theme",
            "light"
        );

    }


    /* عند الضغط */

    darkMode.addEventListener(
        "change",
        function () {

            if (this.checked) {

                document.documentElement.setAttribute(
                    "data-theme",
                    "dark"
                );

                localStorage.setItem(
                    "studyos_theme",
                    "dark"
                );

            } else {

                document.documentElement.setAttribute(
                    "data-theme",
                    "light"
                );

                localStorage.setItem(
                    "studyos_theme",
                    "light"
                );

            }

        }
    );

}


/* =====================================================
   LANGUAGE
===================================================== */

function setupLanguage() {

    updateLanguageChecks();

    updateLanguageText();

}


/* =====================================================
   OPEN LANGUAGE
===================================================== */

function openLanguage() {

    const modal =
        document.getElementById(
            "languageModal"
        );

    if (!modal) return;

    modal.classList.add("show");

    updateLanguageChecks();

}


/* =====================================================
   CLOSE LANGUAGE
===================================================== */

function closeLanguage() {

    const modal =
        document.getElementById(
            "languageModal"
        );

    if (!modal) return;

    modal.classList.remove("show");

}


/* =====================================================
   CHANGE LANGUAGE
===================================================== */

function changeLanguage(language) {

    if (
        language !== "ar" &&
        language !== "ku" &&
        language !== "en"
    ) {

        return;

    }


    /* حفظ اللغة */

    localStorage.setItem(
        "studyos_language",
        language
    );


    /* اتجاه الصفحة */

    if (language === "en") {

        document.documentElement.dir =
            "ltr";

        document.documentElement.lang =
            "en";

    } else {

        document.documentElement.dir =
            "rtl";

        document.documentElement.lang =
            language;

    }


    updateLanguageText();

    updateLanguageChecks();

    closeLanguage();

}


/* =====================================================
   UPDATE LANGUAGE NAME
===================================================== */

function updateLanguageText() {

    const languageName =
        document.querySelector(
            ".language-name"
        );


    if (!languageName) return;


    const language =
        localStorage.getItem(
            "studyos_language"
        ) || "ar";


    if (language === "ar") {

        languageName.textContent =
            "العربية";

    }

    else if (language === "ku") {

        languageName.textContent =
            "کوردی";

    }

    else {

        languageName.textContent =
            "English";

    }

}


/* =====================================================
   UPDATE CHECK MARKS
===================================================== */

function updateLanguageChecks() {

    const language =
        localStorage.getItem(
            "studyos_language"
        ) || "ar";


    const ar =
        document.getElementById(
            "check-ar"
        );

    const ku =
        document.getElementById(
            "check-ku"
        );

    const en =
        document.getElementById(
            "check-en"
        );


    if (ar) {

        ar.textContent =
            language === "ar"
                ? "✓"
                : "";

    }


    if (ku) {

        ku.textContent =
            language === "ku"
                ? "✓"
                : "";

    }


    if (en) {

        en.textContent =
            language === "en"
                ? "✓"
                : "";

    }

}


/* =====================================================
   ACCOUNT
===================================================== */

function openAccount() {

    alert(
        "صفحة الحساب سيتم بناؤها لاحقًا."
    );

}


/* =====================================================
   ABOUT
===================================================== */

function openAbout() {

    alert(
        "صفحة حول StudyOS سيتم بناؤها لاحقًا."
    );

}


/* =====================================================
   PRIVACY
===================================================== */

function openPrivacy() {

    alert(
        "صفحة الخصوصية والشروط سيتم بناؤها لاحقًا."
    );

}


/* =====================================================
   LOGOUT
===================================================== */

function logout() {

    const language =
        localStorage.getItem(
            "studyos_language"
        ) || "ar";


    let message =
        "هل أنت متأكد من تسجيل الخروج؟";


    if (language === "en") {

        message =
            "Are you sure you want to log out?";

    }

    if (language === "ku") {

        message =
            "دڵنیایت لە چوونەدەرەوە؟";

    }


    const result =
        confirm(message);


    if (!result) return;


    localStorage.removeItem(
        "studyos_user"
    );


    window.location.href =
        "../index.html";

}


/* =====================================================
   NAVIGATION
===================================================== */

function navigate(page) {

    const pages = {

        home:
            "../home/home.html",

        questions:
            "../questions/questions.html",

        admission:
            "../admission/admission.html",

        news:
            "../news/news.html",

        settings:
            "../settings/settings.html"

    };


    if (!pages[page]) {

        console.error(
            "StudyOS: الصفحة غير موجودة:",
            page
        );

        return;

    }


    window.location.href =
        pages[page];

}


/* =====================================================
   CLOSE MODAL BY CLICKING OUTSIDE
===================================================== */

document.addEventListener(
    "click",
    function (event) {

        const modal =
            document.getElementById(
                "languageModal"
            );


        if (!modal) return;


        if (event.target === modal) {

            closeLanguage();

        }

    }
);


/* =====================================================
   ESC
===================================================== */

document.addEventListener(
    "keydown",
    function (event) {

        if (event.key === "Escape") {

            closeLanguage();

        }

    }
);