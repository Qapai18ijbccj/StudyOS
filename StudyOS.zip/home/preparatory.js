/* =========================================
   StudyOS - Preparatory
========================================= */


/* =========================================
   الرجوع إلى Home
========================================= */

function goBack() {

    window.location.href =
        "home.html";

}


/* =========================================
   فتح الصف
========================================= */

function openGrade(grade) {

    switch (grade) {

        case "fourth-science":

            openGradePage(
                "fourth-science",
                "الرابع العلمي"
            );

            break;


        case "fifth-science":

            openGradePage(
                "fifth-science",
                "الخامس العلمي"
            );

            break;


        case "sixth-science":

            openGradePage(
                "sixth-science",
                "السادس العلمي"
            );

            break;


        case "fourth-literary":

            openGradePage(
                "fourth-literary",
                "الرابع الأدبي"
            );

            break;


        case "fifth-literary":

            openGradePage(
                "fifth-literary",
                "الخامس الأدبي"
            );

            break;


        case "sixth-literary":

            openGradePage(
                "sixth-literary",
                "السادس الأدبي"
            );

            break;

    }

}


/* =========================================
   الانتقال إلى صفحة الصف
========================================= */

function openGradePage(id, name) {

    /*
       نخزن اسم الصف مؤقتًا.
       لاحقًا نستخدمه لجلب:
       المواد
       الكتب
       الملازم
       الدروس
       الاختبارات
    */

    localStorage.setItem(
        "selectedGrade",
        id
    );

    localStorage.setItem(
        "selectedGradeName",
        name
    );


    window.location.href =
        "grade.html";

}


/* =========================================
   Bottom Navigation
========================================= */

function navigate(page) {

    switch (page) {

        case "home":

            window.location.href =
                "home.html";

            break;


        case "questions":

            window.location.href =
                "../questions/questions.html";

            break;


        case "admission":

            window.location.href =
                "../admission/admission.html";

            break;


        case "news":

            window.location.href =
                "../news/news.html";

            break;


        case "settings":

            window.location.href =
                "../settings/settings.html";

            break;

    }

}


/* =========================================
   تأثير الضغط
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        const buttons =
            document.querySelectorAll(
                "button"
            );

        buttons.forEach(button => {

            button.addEventListener(
                "touchstart",
                () => {

                    button.style.transform =
                        "scale(.97)";

                }
            );

            button.addEventListener(
                "touchend",
                () => {

                    setTimeout(() => {

                        button.style.transform =
                            "";

                    }, 100);

                }
            );

        });

    }
);