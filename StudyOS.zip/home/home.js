/* =========================================
   StudyOS HOME
========================================= */


/* =========================================
   التنقل الرئيسي
========================================= */

function navigate(page) {

    switch (page) {

        case "home":

            window.location.href =
                "home.html";

            break;


        case "questions":

            window.location.href =
                "../questions/questions.html";

            break;


        case "admission":

            window.location.href =
                "../admission/admission.html";

            break;


        case "news":

            window.location.href =
                "../news/news.html";

            break;


        case "settings":

            window.location.href =
                "../settings/settings.html";

            break;

    }
}


/* =========================================
   المرحلة المتوسطة
========================================= */

function openMiddle() {

    window.location.href =
        "middle.html";

}


/* =========================================
   المرحلة الإعدادية
========================================= */

function openPreparatory() {

    window.location.href =
        "preparatory.html";

}


/* =========================================
   عرض جميع المراحل
========================================= */

function showAllStages() {

    /*
       حاليًا نوجه المستخدم
       إلى صفحة المراحل.

       لاحقًا نقدر نسوي صفحة
       All Stages مستقلة.
    */

    window.location.href =
        "middle.html";

}


/* =========================================
   الأسئلة
========================================= */

function openQuestions() {

    window.location.href =
        "../questions/questions.html";

}


/* =========================================
   المعدل
========================================= */

function openAdmission() {

    window.location.href =
        "../admission/admission.html";

}


/* =========================================
   الإشعارات
========================================= */

function openNotifications() {

    alert(
        "🔔 لا توجد إشعارات جديدة حاليًا"
    );

}


/* =========================================
   منع الضغط المزدوج
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        const buttons =
            document.querySelectorAll(
                "button"
            );

        buttons.forEach(button => {

            button.addEventListener(
                "touchstart",
                () => {

                    button.style.transform =
                        "scale(.97)";

                }
            );

            button.addEventListener(
                "touchend",
                () => {

                    setTimeout(() => {

                        button.style.transform =
                            "";

                    }, 100);

                }
            );

        });

    }
);/* =========================
   STUDYOS ASSISTANT
========================= */

/* =========================
   STUDYOS ASSISTANT
========================= */

function openStudyOSAssistant() {
    window.location.href = "assistant/assistant.html";
}