/* =====================================
   StudyOS - Middle
===================================== */


/* الرجوع */

function goBack() {

    window.location.href =
        "home.html";

}


/* =====================================
   فتح الصف
===================================== */

function openGrade(grade) {

    let name = "";


    switch (grade) {

        case "first-middle":

            name = "الأول متوسط";

            break;


        case "second-middle":

            name = "الثاني متوسط";

            break;


        case "third-middle":

            name = "الثالث متوسط";

            break;

    }


    localStorage.setItem(
        "selectedGrade",
        grade
    );


    localStorage.setItem(
        "selectedGradeName",
        name
    );


    window.location.href =
        "grade.html";

}


/* =====================================
   Bottom Navigation
===================================== */

function navigate(page) {

    switch (page) {

        case "home":

            window.location.href =
                "home.html";

            break;


        case "questions":

            window.location.href =
                "../questions/questions.html";

            break;


        case "admission":

            window.location.href =
                "../admission/admission.html";

            break;


        case "news":

            window.location.href =
                "../news/news.html";

            break;


        case "settings":

            window.location.href =
                "../settings/settings.html";

            break;

    }

}


/* =====================================
   Touch animation
===================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const buttons =
            document.querySelectorAll(
                "button"
            );


        buttons.forEach(
            function (button) {

                button.addEventListener(
                    "touchstart",
                    function () {

                        this.style.transform =
                            "scale(.97)";

                    }
                );


                button.addEventListener(
                    "touchend",
                    function () {

                        setTimeout(
                            () => {

                                this.style.transform =
                                    "";

                            },
                            100
                        );

                    }
                );

            }
        );

    }
);