/* =========================================
   STUDYOS - QUESTIONS
========================================= */


/* =========================
   SUBJECT DATA
========================= */

const subjects = {

    "sixth-preparatory": [

        {
            name: "اللغة الإنكليزية",
            description: "أسئلة اللغة الإنكليزية",
            icon: "🇬🇧",
            className: "english"
        },

        {
            name: "اللغة العربية",
            description: "أسئلة اللغة العربية",
            icon: "📖",
            className: "arabic"
        },

        {
            name: "التربية الإسلامية",
            description: "أسئلة التربية الإسلامية",
            icon: "☪️",
            className: "islamic"
        },

        {
            name: "رياضيات علمي",
            description: "رياضيات السادس العلمي",
            icon: "📐",
            className: "math"
        },

        {
            name: "رياضيات أدبي",
            description: "رياضيات السادس الأدبي",
            icon: "➗",
            className: "math"
        },

        {
            name: "الأحياء",
            description: "أسئلة الأحياء",
            icon: "🧬",
            className: "biology"
        },

        {
            name: "التاريخ",
            description: "أسئلة التاريخ",
            icon: "📜",
            className: "history"
        },

        {
            name: "الفيزياء",
            description: "أسئلة الفيزياء",
            icon: "⚡",
            className: "physics"
        },

        {
            name: "الجغرافية",
            description: "أسئلة الجغرافية",
            icon: "🌍",
            className: "geography"
        },

        {
            name: "الكيمياء",
            description: "أسئلة الكيمياء",
            icon: "🧪",
            className: "chemistry"
        },

        {
            name: "الاقتصاد",
            description: "أسئلة الاقتصاد",
            icon: "💰",
            className: "economics"
        }

    ],


    "third-middle": [

        {
            name: "اللغة الإنكليزية",
            description: "أسئلة اللغة الإنكليزية",
            icon: "🇬🇧",
            className: "english"
        },

        {
            name: "اللغة العربية",
            description: "أسئلة اللغة العربية",
            icon: "📖",
            className: "arabic"
        },

        {
            name: "التربية الإسلامية",
            description: "أسئلة التربية الإسلامية",
            icon: "☪️",
            className: "islamic"
        },

        {
            name: "الرياضيات",
            description: "أسئلة الرياضيات",
            icon: "➗",
            className: "math"
        },

        {
            name: "الأحياء",
            description: "أسئلة الأحياء",
            icon: "🧬",
            className: "biology"
        },

        {
            name: "الاجتماعيات",
            description: "أسئلة الاجتماعيات",
            icon: "🌍",
            className: "geography"
        },

        {
            name: "الكيمياء",
            description: "أسئلة الكيمياء",
            icon: "🧪",
            className: "chemistry"
        },

        {
            name: "الفيزياء",
            description: "أسئلة الفيزياء",
            icon: "⚡",
            className: "physics"
        }

    ]

};


/* =========================
   SELECT GRADE
========================= */

function selectGrade(grade) {

    const subjectsSection =
        document.getElementById("subjectsSection");

    const subjectsGrid =
        document.getElementById("subjectsGrid");

    const title =
        document.getElementById("selectedGradeTitle");


    subjectsGrid.innerHTML = "";


    /* TITLE */

    if (grade === "sixth-preparatory") {

        title.textContent =
            "السادس الإعدادي";

    } else {

        title.textContent =
            "الثالث متوسط";

    }


    /* SUBJECTS */

    subjects[grade].forEach((subject) => {

        const card =
            document.createElement("button");

        card.className =
            `subject-card ${subject.className}`;


        card.innerHTML = `

            <div class="subject-icon">
                ${subject.icon}
            </div>

            <strong>
                ${subject.name}
            </strong>

            <span>
                ${subject.description}
            </span>

            <div class="subject-arrow">
                ←
            </div>

        `;


        card.addEventListener(
            "click",
            function () {

                openSubject(
                    grade,
                    subject.name
                );

            }
        );


        subjectsGrid.appendChild(card);

    });


    /* SHOW */

    subjectsSection.classList.add("show");


    /* SCROLL */

    setTimeout(() => {

        subjectsSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }, 100);

}


/* =========================
   CHANGE GRADE
========================= */

function changeGrade() {

    const subjectsSection =
        document.getElementById("subjectsSection");

    subjectsSection.classList.remove("show");

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================
   OPEN SUBJECT
========================= */

function openSubject(
    grade,
    subject
) {

    /*
        لاحقاً نربط هنا
        صفحة الأسئلة الحقيقية.

        مثال:

        questions-list.html?
        grade=sixth-preparatory&
        subject=physics
    */


    const params =
        new URLSearchParams();

    params.set(
        "grade",
        grade
    );

    params.set(
        "subject",
        subject
    );


    /*
        حالياً فقط نعرض رسالة
        إلى أن نبني صفحة الأسئلة
        نفسها.
    */

    alert(
        "سيتم فتح أسئلة: " +
        subject
    );

}


/* =========================
   NAVIGATION
========================= */

function navigate(page) {

    const routes = {

        home:
            "../home/home.html",

        questions:
            "questions.html",

        admission:
            "../admission/admission.html",

        news:
            "../news/news.html",

        settings:
            "../settings/settings.html"

    };


    if (routes[page]) {

        window.location.href =
            routes[page];

    }

}