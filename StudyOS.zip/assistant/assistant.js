/* =========================================
   STUDYOS AI ASSISTANT
========================================= */


/* =========================
   ELEMENTS
========================= */

const chatArea =
    document.getElementById("chatArea");

const messages =
    document.getElementById("messages");

const messageInput =
    document.getElementById("messageInput");

const welcome =
    document.getElementById("welcome");


/* =========================
   SEND MESSAGE
========================= */

function sendMessage() {

    const text =
        messageInput.value.trim();


    if (!text) {
        return;
    }


    addMessage(
        text,
        "user"
    );


    messageInput.value = "";

    autoResize();


    showTyping();


    /*
        مؤقتاً نستخدم رد تجريبي.

        لاحقاً هنا بالضبط نربط
        Backend / AI API.

        مثال مستقبلي:

        fetch("/api/assistant", {
            method: "POST",
            body: JSON.stringify({
                message: text
            })
        })
    */


    setTimeout(() => {

        removeTyping();

        generateDemoReply(text);

    }, 900);

}


/* =========================
   ADD MESSAGE
========================= */

function addMessage(
    text,
    type
) {

    const message =
        document.createElement("div");

    message.className =
        `message ${type}`;


    const bubble =
        document.createElement("div");

    bubble.className =
        "message-bubble";

    bubble.textContent =
        text;


    message.appendChild(bubble);

    messages.appendChild(message);


    document
        .querySelector(".chat-area")
        .classList.add("has-messages");


    scrollToBottom();
}


/* =========================
   QUICK PROMPT
========================= */

function quickPrompt(text) {

    messageInput.value =
        text;

    sendMessage();

}


/* =========================
   DEMO AI REPLY
========================= */

function generateDemoReply(text) {

    let reply =
        "🤖 أنا جاهز لمساعدتك بالدراسة!";


    const lower =
        text.toLowerCase();


    if (
        lower.includes("اشرح") ||
        lower.includes("شرح")
    ) {

        reply =
            "أكيد 👍\n\n" +
            "حالياً هذه نسخة تجريبية من مساعد StudyOS. " +
            "عند ربط المساعد بالذكاء الاصطناعي الحقيقي " +
            "أقدر أشرح لك الدروس خطوة بخطوة وبطريقة تناسب صفك.";

    }

    else if (
        lower.includes("اختبرني") ||
        lower.includes("اختبار")
    ) {

        reply =
            "📝 ممتاز!\n\n" +
            "بعد ربط بنك الأسئلة، أقدر أسوي لك اختبار " +
            "حسب الصف والمادة وأحسب نتيجتك أيضاً.";

    }

    else if (
        lower.includes("لخص") ||
        lower.includes("تلخيص")
    ) {

        reply =
            "🧠 أرسل لي النص أو الدرس، " +
            "وبعد ربط الذكاء الاصطناعي أقدر أختصره لك " +
            "إلى أهم النقاط بطريقة سهلة للحفظ.";

    }

    else if (
        lower.includes("سؤال") ||
        lower.includes("حل")
    ) {

        reply =
            "📚 أرسل السؤال، وسأشرح لك طريقة الحل " +
            "خطوة بخطوة بدل إعطائك الجواب فقط.";

    }


    addMessage(
        reply,
        "ai"
    );

}


/* =========================
   TYPING
========================= */

function showTyping() {

    if (
        document.getElementById("typingMessage")
    ) {
        return;
    }


    const message =
        document.createElement("div");

    message.className =
        "message ai";

    message.id =
        "typingMessage";


    message.innerHTML = `

        <div class="message-bubble">

            <div class="typing">

                <span></span>
                <span></span>
                <span></span>

            </div>

        </div>

    `;


    messages.appendChild(message);

    scrollToBottom();
}


/* =========================
   REMOVE TYPING
========================= */

function removeTyping() {

    const typing =
        document.getElementById(
            "typingMessage"
        );


    if (typing) {

        typing.remove();

    }

}


/* =========================
   SCROLL
========================= */

function scrollToBottom() {

    setTimeout(() => {

        chatArea.scrollTo({

            top:
                chatArea.scrollHeight,

            behavior:
                "smooth"

        });

    }, 50);

}


/* =========================
   AUTO RESIZE
========================= */

messageInput.addEventListener(
    "input",
    autoResize
);


function autoResize() {

    messageInput.style.height =
        "auto";

    messageInput.style.height =
        Math.min(
            messageInput.scrollHeight,
            120
        ) + "px";

}


/* =========================
   ENTER TO SEND
========================= */

messageInput.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Enter" &&
            !event.shiftKey
        ) {

            event.preventDefault();

            sendMessage();

        }

    }
);


/* =========================
   NEW CHAT
========================= */

function newChat() {

    messages.innerHTML = "";

    chatArea.classList.remove(
        "has-messages"
    );

    messageInput.value = "";

    messageInput.style.height =
        "auto";

    scrollToBottom();

}


/* =========================
   BACK
========================= */

function goBack() {

    if (
        window.history.length > 1
    ) {

        window.history.back();

    } else {

        window.location.href =
            "../home/home.html";

    }

}