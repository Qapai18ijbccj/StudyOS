/* =========================
   STUDYOS NEWS
========================= */

const newsData = [

    {
        title: "وزارة التربية تعلن استعداداتها للعام الدراسي الجديد",
        category: "education",
        categoryName: "وزارة التربية",
        description:
            "أعلنت وزارة التربية عن مجموعة من الاستعدادات والخطط الجديدة لدعم الطلبة وتطوير البيئة التعليمية خلال العام الدراسي الجديد.",
        date: "اليوم • 10:30 صباحاً",
        color: ""
    },

    {
        title: "فتح باب التقديم الإلكتروني لعدد من الجامعات",
        category: "universities",
        categoryName: "الجامعات",
        description:
            "تتواصل الاستعدادات الخاصة بالتقديم الإلكتروني، مع توفير معلومات إضافية للطلبة حول الجامعات والتخصصات المتاحة.",
        date: "اليوم • 09:15 صباحاً",
        color: "blue"
    },

    {
        title: "تعليمات جديدة تخص الامتحانات النهائية",
        category: "exams",
        categoryName: "الامتحانات",
        description:
            "تتضمن التعليمات الجديدة مجموعة من التوجيهات المهمة للطلبة بشأن الامتحانات وتنظيم عملية أداء الاختبارات.",
        date: "أمس • 08:40 مساءً",
        color: "orange"
    },

    {
        title: "دليل الطالب للتقديم والقبول الجامعي",
        category: "admission",
        categoryName: "القبول",
        description:
            "دليل مبسط يساعد الطلبة على فهم خطوات التقديم واختيار التخصص والاطلاع على المعلومات المتعلقة بالقبول الجامعي.",
        date: "أمس • 05:20 مساءً",
        color: "purple"
    },

    {
        title: "وزارة التربية توضح أهمية متابعة التعليمات الرسمية",
        category: "education",
        categoryName: "وزارة التربية",
        description:
            "أكدت الوزارة أهمية اعتماد الطلبة على المصادر الرسمية عند متابعة الأخبار والتعليمات المتعلقة بالدراسة والامتحانات.",
        date: "10 أغسطس • 01:30 ظهراً",
        color: "red"
    },

    {
        title: "جامعات عراقية تستعد لاستقبال الطلبة الجدد",
        category: "universities",
        categoryName: "الجامعات",
        description:
            "بدأت الجامعات استعداداتها لاستقبال الطلبة الجدد وتوفير الخدمات والمعلومات اللازمة للطلبة.",
        date: "9 أغسطس • 06:10 مساءً",
        color: "teal"
    }

];


/* =========================
   ELEMENTS
========================= */

const newsList =
    document.getElementById("newsList");

const searchInput =
    document.getElementById("searchInput");

const emptyState =
    document.getElementById("emptyState");

const newsCount =
    document.getElementById("newsCount");

const categories =
    document.querySelectorAll(".category");

const newsModal =
    document.getElementById("newsModal");

const modalTitle =
    document.getElementById("modalTitle");

const modalDescription =
    document.getElementById("modalDescription");

const modalCategory =
    document.getElementById("modalCategory");

const modalDate =
    document.getElementById("modalDate");


let currentCategory = "all";


/* =========================
   DISPLAY NEWS
========================= */

function renderNews() {

    const search =
        searchInput.value
            .trim()
            .toLowerCase();


    const filtered =
        newsData.filter(news => {

            const matchesCategory =
                currentCategory === "all" ||
                news.category === currentCategory;


            const matchesSearch =
                news.title
                    .toLowerCase()
                    .includes(search) ||

                news.description
                    .toLowerCase()
                    .includes(search) ||

                news.categoryName
                    .toLowerCase()
                    .includes(search);


            return matchesCategory &&
                   matchesSearch;

        });


    newsList.innerHTML = "";


    newsCount.textContent =
        `${filtered.length} أخبار`;


    if (filtered.length === 0) {

        emptyState.style.display = "block";

        return;

    }


    emptyState.style.display = "none";


    filtered.forEach((news, index) => {

        const card =
            document.createElement("article");

        card.className =
            "news-card";


        card.onclick = () => {

            const realIndex =
                newsData.indexOf(news);

            openNews(realIndex);

        };


        card.innerHTML = `

            <div class="news-thumbnail ${news.color}">

                ${news.categoryName}

            </div>


            <div class="news-info">

                <span class="tag">
                    ${news.categoryName}
                </span>

                <h3>
                    ${news.title}
                </h3>

                <p>
                    ${news.description}
                </p>

                <span class="news-date">
                    ${news.date}
                </span>

            </div>

        `;


        newsList.appendChild(card);

    });

}


/* =========================
   SEARCH
========================= */

searchInput.addEventListener(
    "input",
    renderNews
);


/* =========================
   CATEGORIES
========================= */

categories.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            categories.forEach(item => {

                item.classList.remove(
                    "active"
                );

            });


            button.classList.add(
                "active"
            );


            currentCategory =
                button.dataset.category;


            renderNews();

        }
    );

});


/* =========================
   OPEN NEWS
========================= */

function openNews(index) {

    const news =
        newsData[index];


    if (!news) return;


    modalTitle.textContent =
        news.title;


    modalDescription.textContent =
        news.description;


    modalCategory.textContent =
        news.categoryName;


    modalDate.textContent =
        news.date;


    newsModal.classList.add(
        "show"
    );


    document.body.style.overflow =
        "hidden";

}


/* =========================
   CLOSE NEWS
========================= */

function closeNews() {

    newsModal.classList.remove(
        "show"
    );


    document.body.style.overflow =
        "";

}


/* =========================
   CLOSE WHEN CLICK OUTSIDE
========================= */

newsModal.addEventListener(
    "click",
    function(event) {

        if (
            event.target === newsModal
        ) {

            closeNews();

        }

    }
);


/* =========================
   NAVIGATION
========================= */

function navigate(page) {

    const pages = {

        home:
            "../home/home.html",

        questions:
            "../questions/questions.html",

        admission:
            "../admission/admission.html",

        news:
            "news.html",

        settings:
            "../settings/settings.html"

    };


    if (pages[page]) {

        window.location.href =
            pages[page];

    }

}


/* =========================
   START
========================= */

renderNews();